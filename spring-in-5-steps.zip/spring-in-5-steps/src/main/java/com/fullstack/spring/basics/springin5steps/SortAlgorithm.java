package com.fullstack.spring.basics.springin5steps;

public interface SortAlgorithm {
	
	public int[] sort(int[] numbers);

}
