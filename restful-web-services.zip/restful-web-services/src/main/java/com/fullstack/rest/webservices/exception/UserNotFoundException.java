package com.fullstack.rest.webservices.exception;

public class UserNotFoundException extends RuntimeException{

	public UserNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	
}
